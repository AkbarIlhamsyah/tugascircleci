// Export pages
export '/splash_screen/after_splash_screen1/after_splash_screen1_widget.dart'
    show AfterSplashScreen1Widget;
export '/splash_screen/after_splash_screen2/after_splash_screen2_widget.dart'
    show AfterSplashScreen2Widget;
export '/splash_screen/after_splash_screen3/after_splash_screen3_widget.dart'
    show AfterSplashScreen3Widget;
export '/login_page/login/login_widget.dart' show LoginWidget;
export '/dashboard/menu_page/menu_page_widget.dart' show MenuPageWidget;
export '/dashboard/point_redeem_page/point_redeem_page_widget.dart'
    show PointRedeemPageWidget;
export '/dashboard/account_page/account_page_widget.dart'
    show AccountPageWidget;
export '/c_r_u_d_menu/edit_menu/edit_menu_widget.dart' show EditMenuWidget;
