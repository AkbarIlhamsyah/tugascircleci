import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'after_splash_screen3_model.dart';
export 'after_splash_screen3_model.dart';

/// Choose and customize your Drinks
class AfterSplashScreen3Widget extends StatefulWidget {
  const AfterSplashScreen3Widget({super.key});

  static String routeName = 'AfterSplashScreen3';
  static String routePath = '/afterSplashScreen3';

  @override
  State<AfterSplashScreen3Widget> createState() =>
      _AfterSplashScreen3WidgetState();
}

class _AfterSplashScreen3WidgetState extends State<AfterSplashScreen3Widget> {
  late AfterSplashScreen3Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AfterSplashScreen3Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SafeArea(
          top: true,
          child: Stack(
            children: [
              Align(
                alignment: AlignmentDirectional(0.0, -1.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 200.0, 0.0, 0.0),
                  child: Container(
                    width: 900.0,
                    height: 450.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.network(
                        'https://images.unsplash.com/photo-1518057111178-44a106bad636?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w0NTYyMDF8MHwxfHNlYXJjaHwzfHxjb2ZmZWV8ZW58MHx8fHwxNzQxMTYxOTE2fDA&ixlib=rb-4.0.3&q=80&w=1080',
                        width: 200.0,
                        height: 200.0,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.1),
                child: Container(
                  width: 900.0,
                  height: 100.0,
                  decoration: BoxDecoration(),
                  child: Text(
                    'Get and Redeem Voucher',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Poppins',
                          fontSize: 50.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.27),
                child: Container(
                  width: 900.0,
                  height: 100.0,
                  decoration: BoxDecoration(),
                  child: Text(
                    'Exciting prizes await you! Redeem yours by collecting all the points after purchase in the app!',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Poppins',
                          fontSize: 30.0,
                          letterSpacing: 0.0,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.8, 0.7),
                child: FFButtonWidget(
                  onPressed: () {
                    print('Button pressed ...');
                  },
                  text: 'NEXT',
                  options: FFButtonOptions(
                    width: 300.0,
                    height: 80.0,
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: Color(0xFF067302),
                    textStyle:
                        FlutterFlowTheme.of(context).displayMedium.override(
                              fontFamily: 'Poppins',
                              color: Colors.white,
                              fontSize: 30.0,
                              letterSpacing: 0.0,
                            ),
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.9, -0.9),
                child: Text(
                  'SKIP',
                  style: FlutterFlowTheme.of(context).labelLarge.override(
                        fontFamily: 'Poppins',
                        fontSize: 35.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w800,
                      ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
